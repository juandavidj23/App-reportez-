package com.example.custom_input

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
